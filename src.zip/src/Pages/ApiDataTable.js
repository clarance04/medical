import axios from 'axios';
import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component'

export default function Api() {
    
const [userlist,setUserlist] = useState([]);
const [search, setSearch] = useState([]);
const [filterdata, setFilterdata] = useState([]);
console.log(search, 'search is');
console.log(userlist);

    useEffect (() => {
        axios
        .get("https://jsonplaceholder.typicode.com/todos")
        .then((res) => {
          setUserlist(res.data);
          setFilterdata(res.data);
        })
        .catch((err) => console.log(err));
    },[]);

    const column = [
      {
        name: "Id",
        selector: (row) => row.id,
      },

      {
        name: "Userid",
        selector: (row) => row.userId,
      },

      {
        name: "Title",
        selector: (row) => row.title,
      },
    ];

    useEffect (() => {
      const datas =userlist.filter((res) => {
        return res.name.toLowerCase().match(search.toLowerCase());
      });
      setFilterdata(datas);
    }, [search]);




  return (
    <div>
      <DataTable
      columns = {column}
      data = {filterdata}
      pagination
      title = "Data"
      fixedHeader
      subHeader
      subHeaderComponent={
        <input
        type="text"
        className='form-control'
        style={{width: "200px"}}
        placeholder = 'search data'
        onChange={(e) => setSearch(e.target.value)}
        />
      }
      />
      {/* <table>
            <tr>
                <th>s.no</th>
                <th>name</th>
                <th>username</th>
                <th>email</th>
            </tr>
            {userlist.map((res, index)=>{
                return(
                    <>
                    <tr>
                        <td>{index + 1}</td>
                        <td>{res.name}</td>
                        <td>{res.username}</td>
                        <td>{res.email}</td>
                    </tr>
                    </>
                )
            })}
        </table>  */}
    </div>
  )
}

