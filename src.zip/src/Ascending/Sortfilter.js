import React, { useContext, useState } from 'react'
import data from '../MOCK_DATA.json'


export default function Sortfilter() {
    const [values,setValues] = useState([]) 

       console.log(data)
        
    
  return (
    <div>

    </div>
  )
}
